package variables;

public class Inheritance {
	
	public Inheritance() {
		System.out.println("Hello");
	}
	public static void car(int num1,int num2) {
		System.out.println(num1+num2);
	}
	public static void main(String[] args) {
		
		car(2,4);
	}

}
