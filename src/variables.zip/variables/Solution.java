package variables;

public class Solution {
	public static int getCentury(int year) {
        return (year + 99) / 100;
    }
    
    public static void main(String[] args) {
        // Example usage
        System.out.println(getCentury(1905)); // Outputs 20
        System.out.println(getCentury(2000)); // Outputs 20
        System.out.println(getCentury(2001)); // Outputs 21
    }
	
}
